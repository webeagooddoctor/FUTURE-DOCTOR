#!/bin/bash
echo "Installing dependencies..."
npm install
echo "Setup complete."
